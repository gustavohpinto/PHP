<?php 
	
	session_start();

	if (
		(!isset($_SESSION['idUsuario'])==true)&&
		(!isset($_SESSION['nome'])==true)&&
		(!isset($_SESSION['email'])==true)){

		unset($_SESSION['idUsuario']);
		unset($_SESSION['nome']);
		unset($_SESSION['email']);

		header('Location: index.html');
	}

	echo "PARABÉNS";

?>

<a href="sair.php"> SAIR </a>